# CHANGELOG FOR MPPGv4 XML/SOAP EXAMPLE MESSAGES FOR USE WITH MPPG EMV INTEGRATION GUIDE

## 2020-01-26  Chuck Maggs <chuck.maggs@magtek.com>
* Created MPPGv4 XML/SOAP example messages for MPPG EMV integration guide
